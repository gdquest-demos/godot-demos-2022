# Juicy sword attacks

This demo shows a sword attack with layered visual effects and sound to help the player feel the weight of attacks.

