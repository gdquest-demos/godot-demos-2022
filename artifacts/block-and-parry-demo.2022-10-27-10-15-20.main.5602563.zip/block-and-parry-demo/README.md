# Block and parry demo

This demo shows how to block attacks with a shield area in front of the player character. It also shows how to implement a timed parry mechanic. 

Keep the spacebar pressed to block. Press the spacebar when the enemy is about to hit you to do a perfect parry and stun them.

![](block-screenshot.png)
